#!/bin/sh
#Step 1 — Creating a Data Directory for ZooKeeper

sudo mkdir -p /data/zookeeper
sudo chown -R osboxes:osboxes /data/zookeeper

# Step-2 declare the server's identity
echo "1" > /data/zookeeper/myid

# Step-3 edit the zookeeper settings
rm /home/osboxes/kafka/config/zookeeper.properties
vi /home/osboxes/kafka/config/zookeeper.properties

# Copy the content from zk_quorum.properties provided in your config diretory.
server.1=zookeeper1:2888:3888
server.2=zookeeper2:2888:3888
server.3=zookeeper3:2888:3888

# Step-4 restart the zookeeper service

sudo service zookeeper stop
sudo service zookeeper start

# Step-5 observe the logs - need to do this on every machine

cat /home/osboxes/kafka/logs/zookeeper.out | head -100
# Run below commands to check if the ports are up.
nc -vz localhost 2181
nc -vz localhost 2888
nc -vz localhost 3888
# If you get "imok" then your cluster is looking good.
echo "ruok" | nc localhost 2181 ; echo
# In your "stat" result you should see Cluster information.
echo "stat" | nc localhost 2181 ; echo
# Below is zookeeper shell command to invoke zookeeper sheel and ls the root znode.
bin/zookeeper-shell.sh localhost:2181 ls /

# Below command will tell you if your server is Leader or Follower.
echo stat | nc localhost 2181 | grep Mode
